// ignore_for_file: file_names, library_private_types_in_public_api, avoid_print

import 'dart:async';
import 'package:flutter/material.dart';
import 'Product.dart';

class EcommerceApp extends StatefulWidget {
  const EcommerceApp({Key? key}) : super(key: key);

  @override
  _EcommerceAppState createState() => _EcommerceAppState();
}

class _EcommerceAppState extends State<EcommerceApp>
    with SingleTickerProviderStateMixin {
  bool _isDarkModeOn = false;
  int _currentIndex = 0;
  final PageController _pageController = PageController();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _animation =
        Tween<double>(begin: 0, end: 0.3).animate(_animationController);
    _animationController.repeat(reverse: true);
    // Automatically scroll through items every 3 seconds
    Timer.periodic(const Duration(seconds: 3), (Timer timer) {
      if (_currentIndex < 4) {
        _currentIndex++;
      } else {
        _currentIndex = 0;
      }
      _pageController.animateToPage(
        _currentIndex,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _toggleTheme() {
    setState(() {
      _isDarkModeOn = !_isDarkModeOn;
    });
  }

  void _performSearch() {
    setState(() {
      _searchQuery = _searchController.text;
    });

    // Implement your search logic here
    print('Performing search for: $_searchQuery');
  }

  ThemeData _getThemeData() {
    if (_isDarkModeOn) {
      return ThemeData.dark().copyWith(
        primaryColor: Colors.black,
        hintColor: Colors.white,
      );
    } else {
      return ThemeData.light().copyWith(
        primaryColor: Colors.white,
        hintColor: Colors.black,
      );
    }
  }

  Widget buildHeader(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          height: 80.0,
          decoration: BoxDecoration(
            color: _isDarkModeOn ? Colors.black : Colors.white,
            border: const Border(
              bottom: BorderSide(
                color: Colors.grey,
                width: 1.0,
              ),
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Transform(
                alignment: Alignment.center,
                transform: Matrix4.identity()..rotateY(_animation.value),
                child: Text(
                  'Ecommerce',
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: _isDarkModeOn ? Colors.white : Colors.black,
                  ),
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: Icon(
                  Icons.person,
                  color: _isDarkModeOn ? Colors.white : Colors.black,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ecommerce',
      theme: _getThemeData(),
      home: Scaffold(
        body: Stack(
          children: [
            ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextField(
                    controller: _searchController,
                    style: TextStyle(color: Theme.of(context).hintColor),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey[300],
                      hintText: 'Search',
                      hintStyle: TextStyle(color: Theme.of(context).hintColor),
                      prefixIcon: const Icon(
                        Icons.search,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                    ),
                    onSubmitted: (_) => _performSearch(),
                  ),
                ),
                const SizedBox(height: 16.0),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.2,
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: 5,
                    onPageChanged: (int index) {
                      setState(() {
                        _currentIndex = index;
                      });
                    },
                    itemBuilder: (context, index) {
                      return Container(
                        width: MediaQuery.of(context).size.width * 0.10,
                        margin: const EdgeInsets.symmetric(horizontal: 8.0),
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Center(
                          child: Image.asset(
                            'assets/images/slider_$index.jpg',
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 22.0),
                Container(
                  padding: const EdgeInsets.all(22.0),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).size.width ~/ 180,
                      childAspectRatio: 0.75,
                    ),
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProductDetailPage(),
                            ),
                          );
                        },
                        child: AnimatedContainer(
                          duration: const Duration(seconds: 1),
                          curve: Curves.easeInOut,
                          transform: Matrix4.identity()
                            ..rotateY(_isDarkModeOn ? 0 : 0.3),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 120.0,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage(
                                        'assets/images/product_$index.jpg',
                                      ),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(9.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Product $index',
                                        style: const TextStyle(fontSize: 14.0),
                                      ),
                                      const SizedBox(height: 4.0),
                                      Row(
                                        children: [
                                          Icon(
                                            Icons.star,
                                            color: _isDarkModeOn
                                                ? Colors.white
                                                : Colors.black,
                                          ),
                                          const SizedBox(width: 4.0),
                                          const Text('4.5'),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            buildHeader(context),
          ],
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _toggleTheme,
          icon: Icon(
            _isDarkModeOn ? Icons.brightness_4 : Icons.brightness_7,
            color: _isDarkModeOn ? Colors.white : Colors.black,
          ),
          label: Text(
            _isDarkModeOn ? 'Dark Theme' : 'Light Theme',
            style: TextStyle(
              color: _isDarkModeOn ? Colors.white : Colors.black,
            ),
          ),
          backgroundColor: _isDarkModeOn ? Colors.black : Colors.white,
        ),
        bottomNavigationBar: BottomAppBar(
          shape: const CircularNotchedRectangle(),
          child: SizedBox(
            height: 56.0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const EcommerceApp(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.home),
                  color: _isDarkModeOn ? Colors.white : Colors.black,
                ),
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const EcommerceApp(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.search),
                  color: _isDarkModeOn ? Colors.white : Colors.black,
                ),
                const SizedBox(width: 48.0), // Placeholder for the center space
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const EcommerceApp(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.shopping_cart),
                  color: _isDarkModeOn ? Colors.white : Colors.black,
                ),
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProductDetailPage(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.settings),
                  color: _isDarkModeOn ? Colors.white : Colors.black,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
