// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';

class BottomNavigation3D extends StatefulWidget {
  const BottomNavigation3D({super.key, required int currentIndex, required Null Function(dynamic index) onChange});

  @override
  _BottomNavigation3DState createState() => _BottomNavigation3DState();
}

class _BottomNavigation3DState extends State<BottomNavigation3D>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  late AnimationController _animationController;
  late Animation<double> _animation;

  final List<IconData> _icons = [
    Icons.home,
    Icons.search,
    Icons.favorite,
    Icons.person,
  ];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onTabTapped(int index) {
    setState(() {
      if (_currentIndex != index) {
        _currentIndex = index;
        _animationController.forward(from: 0);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('3D Bottom Navigation'),
      ),
      body: const Center(
        child: Text('Content for the current tab'),
      ),
      bottomNavigationBar: BottomAppBar(
        elevation: 8,
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(_icons.length, (index) {
            return _buildNavItem(index);
          }),
        ),
      ),
      floatingActionButton: ScaleTransition(
        scale: _animation,
        child: FloatingActionButton(
          onPressed: () {
            // Add your desired action here
          },
          child: const Icon(Icons.add),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildNavItem(int index) {
    return InkWell(
      onTap: () => _onTabTapped(index),
      child: SizedBox(
        width: 56,
        height: 56,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              height: _currentIndex == index ? 60 : 50,
              decoration: BoxDecoration(
                color:
                    _currentIndex == index ? Colors.blue : Colors.transparent,
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            Icon(
              _icons[index],
              color: _currentIndex == index ? Colors.white : Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}
